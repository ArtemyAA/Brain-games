from brain_games.games import brain_even_copy
from brain_games import engine


def main():
    engine.start(brain_even_copy.round())

if __name__ == '__main__':
    main()

