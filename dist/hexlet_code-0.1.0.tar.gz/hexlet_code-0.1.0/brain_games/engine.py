import prompt


def start(game):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    ROUNDS = 3 
    question = game.QUESTION
    print(question)
    while ROUNDS > 0:
        answer, query_content = game.round()
        print(game.query_content)
        ans = game.answer_type(input('Your answer: '))
        if ans == answer:
            ROUNDS -= 1
            print('Correct!')
        else:
            print('"yes" is wrong answer ;(. Correct answer was "no".')
            print(f"Let's try again, {name}! ")
            break
    if ROUNDS == 0:
        print(f'Congratulations, {name}!')