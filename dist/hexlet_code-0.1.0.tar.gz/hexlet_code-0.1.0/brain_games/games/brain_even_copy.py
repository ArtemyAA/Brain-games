#!/usr/bin/env python3

from random import randint


QUESTION:str = 'Answer "yes" if the number is even, otherwise answer "no".'

def round():
    asked_number = randint(1, 100)
    query_content = asked_number
    if asked_number % 2 == 0:
        answer = 'yes'
    else:
        answer = 'no' 
    return answer, query_content
        
