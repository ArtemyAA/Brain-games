### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtemyAA/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtemyAA/python-project-49/actions)
<a href="https://codeclimate.com/github/ArtemyAA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4bbb589b663890b2660f/maintainability" /></a>
1. Brain-even game video 

https://asciinema.org/a/628712

2. Brain-calc game video

https://asciinema.org/a/ON36qal0vUbvZg9s2Zavxnagf
