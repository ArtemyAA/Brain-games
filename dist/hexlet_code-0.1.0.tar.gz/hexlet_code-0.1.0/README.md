### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtemyAA/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtemyAA/python-project-49/actions)
<a href="https://codeclimate.com/github/ArtemyAA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4bbb589b663890b2660f/maintainability" /></a>

# Here are different versions of brain game! Use same commands which are used in videos to play them.

1. EVEN game video 

https://asciinema.org/a/628976

2. CALC game video

https://asciinema.org/a/628973

3. GCD game video

https://asciinema.org/a/628977

4. PROGRESSION game video

https://asciinema.org/a/628998

5. PRIME game video

https://asciinema.org/a/629045
