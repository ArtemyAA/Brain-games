### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArtemyAA/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ArtemyAA/python-project-49/actions)
<a href="https://codeclimate.com/github/ArtemyAA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4bbb589b663890b2660f/maintainability" /></a>

### Here are different versions of brain game! Use same commands which are used in videos to play them.

1. EVEN game video 

<script async id="asciicast-628976" src="https://asciinema.org/a/628976.js"></script>

2. CALC game video

<script async id="asciicast-628973" src="https://asciinema.org/a/628973.js"></script>

3. GCD game video

<script async id="asciicast-628977" src="https://asciinema.org/a/628977.js"></script>

4. PROGRESSION game video

<script async id="asciicast-628998" src="https://asciinema.org/a/628998.js"></script>

5. PRIME game video

<script async id="asciicast-629045" src="https://asciinema.org/a/629045.js"></script>
